const fs = require("fs");
module.exports.config = {
	name: "prefix",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "Jhiem Rhai", 
	description: "no prefix",
	commandCategory: "No command marks needed",
	usages: "...",
    cooldowns: 1, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("prefix")==0 || (event.body.indexOf("Prefix")==0 || (event.body.indexOf("Ano prefix")==0 || (event.body.indexOf("ano prefix")==0)))) {
    const moment = require("moment-timezone");
    var gio = moment.tz("Asia/Manila").format("HH:mm:ss || D/MM/YYYY");
		var msg = {
				body: `Hello! It appears that you’re not familiar with my prefix. Here’s a guide on how to use it!      

🤖 ChatBot Prefix: ${global.config.PREFIX}\n\nIf you are looking for the list of available commands, just enter “${global.config.PREFIX}command.”

If you are looking for my Categories; utilize “${global.config.PREFIX} categories” select the desired category; the available commands for that category will be displayed here.\n\nRead the policy to avoid getting banned.\n\n🌐 Usage: Just type the word “rule”`
			}
			api.sendMessage(msg, threadID, messageID);
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }