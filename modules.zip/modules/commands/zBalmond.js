const fs = require("fs");
module.exports.config = {
	name: "Balmond",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "VanHung - Fixed by LTD", 
	description: "hihihihi",
	commandCategory: "no prefix",
	usages: "sus",
    cooldowns: 5, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("Bal")==0 || event.body.indexOf("bal")==0 || event.body.indexOf("Balmond")==0 || event.body.indexOf("balmond")==0) {
		var msg = {
				body: "What’s your name, boy? 😡",
				attachment: fs.createReadStream(__dirname + `/noprefix/Balmond.jpeg`)
			}
			api.sendMessage(msg, threadID, messageID);
    api.setMessageReaction("😱", event.messageID, (err) => {}, true)
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }