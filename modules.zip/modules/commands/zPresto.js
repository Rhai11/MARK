const fs = require("fs");
module.exports.config = {
	name: "Presto",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "VanHung - Fixed by LTD", 
	description: "hihihihi",
	commandCategory: "no prefix",
	usages: "sus",
    cooldowns: 5, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("presto")==0 || event.body.indexOf("Presto")==0 || event.body.indexOf("Food")==0 || event.body.indexOf("food")==0) {
		var msg = {
				body: "Hi senpai, do you like some food?",
				attachment: fs.createReadStream(__dirname + `/noprefix/Presto.jpeg`)
			}
			api.sendMessage(msg, threadID, messageID);
    api.setMessageReaction("😱", event.messageID, (err) => {}, true)
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }