const fs = require("fs");
const axios = require("axios");

module.exports.config = {
  name: "Kirby",
  version: "5",
  hasPermission: 0,
  credits: "Ck Yg",
  description: "Talk to Kirby!",
  usePrefix: false,
  commandCategory: "Artificial intelligence",
  usages: "prompt",
  cooldowns: 0,
};
module.exports.handleEvent = async function({ api, event }) {
	if (!(event.body.indexOf("Kirby") === 0 || event.body.indexOf("kirby") === 0)) return;

	const args = event.body.split(/\s+/);
  args.shift();
	
  const axios = require('axios');
  let question = args.join(" ");
  if (!question) {
	 return api.sendMessage("Hi, Waddle Dee! Are you ready? I am Kirby! How may I help you? ༼⁠ ⁠つ⁠ ⁠◕⁠‿⁠◕⁠ ⁠༽⁠つ\n\n🌐 Usage: Kirby [question]\n\nPronto Burt you bully, the pleasure will be all mine.  ミ⁠●⁠﹏⁠☉⁠ミ", event.threadID, event.messageID);
  }

	 api.sendMessage(`answering...`, event.threadID, event.messageID);
	api.setMessageReaction("🔄", event.messageID, (err) => {}, true);
  try {
	 const response = await axios.get(`https://openai-rest-api.vercel.app/hercai?ask=${encodeURIComponent(question)}`);
	 const answer = response.data.reply;
	 api.sendMessage(answer, event.threadID, event.messageID);
api.setMessageReaction("🟢", event.messageID, (err) => {}, true);
  } catch (error) {
	 api.sendMessage("Error, please try again later.", event.threadID, event.messageID);
api.setMessageReaction("🔴", event.messageID, (err) => {}, true);
  }
};
module.exports.run = async function ({ api, event }) {
	 api.sendMessage(`This command doesn't need a prefix`, event.threadID, event.messageID);

};