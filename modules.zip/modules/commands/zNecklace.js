const fs = require("fs");
module.exports.config = {
	name: "Necklace",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "VanHung - Fixed by LTD", 
	description: "hihihihi",
	commandCategory: "no prefix",
	usages: "sus",
    cooldowns: 5, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("Neck")==0 || event.body.indexOf("neck")==0 || event.body.indexOf("Necklace")==0 || event.body.indexOf("necklace")==0) {
		var msg = {
				body: "Hello, do you like my new necklace?",
				attachment: fs.createReadStream(__dirname + `/noprefix/Necklace.jpeg`)
			}
			api.sendMessage(msg, threadID, messageID);
    api.setMessageReaction("😱", event.messageID, (err) => {}, true)
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }