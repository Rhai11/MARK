var mysterious = ("Siegfried Sama");
module.exports.config = {
	name: "joke",
	version: "1.0.1",
	hasPermssion: 0,
	credits: `${mysterious}`,
	description: "",
	commandCategory: "Games",
	cooldowns: 5
};

module.exports.run = async ({ api, event,args }) => {
const axios = global.nodemodule["axios"];
const res = await axios.get(`https://api.popcat.xyz/joke`);
var sieg = res.data.joke;
return api.sendMessage(`${sieg}`, event.threadID, event.messageID)
}