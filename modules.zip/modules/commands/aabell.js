const fs = require("fs");
module.exports.config = {
	name: "Abell",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "VanHung - Fixed by LTD", 
	description: "hihihihi",
	commandCategory: "no prefix",
	usages: "sus",
    cooldowns: 5, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("Abil")==0 || event.body.indexOf("Macaraeg")==0 || event.body.indexOf("abill")==0 || event.body.indexOf("Abell")==0) {
		var msg = {
				body: "Subo mo ito",
				attachment: fs.createReadStream(__dirname + `/noprefix/Abell.jpeg`)
			}
			api.sendMessage(msg, threadID, messageID);
    api.setMessageReaction("😱", event.messageID, (err) => {}, true)
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }