const fs = require("fs");
module.exports.config = {
	name: "Gabriela",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "VanHung - Fixed by LTD", 
	description: "hihihihi",
	commandCategory: "no prefix",
	usages: "sus",
    cooldowns: 5, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("Ela")==0 || event.body.indexOf("ilah")==0 || event.body.indexOf("Gabriela")==0 || event.body.indexOf("Ilah")==0) {
		var msg = {
				body: "Hi my baby. 🥵",
				attachment: fs.createReadStream(__dirname + `/noprefix/Ela.jpg`)
			}
			api.sendMessage(msg, threadID, messageID);
    api.setMessageReaction("😱", event.messageID, (err) => {}, true)
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }