const fs = require("fs");
module.exports.config = {
	name: "Akira",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "VanHung - Fixed by LTD", 
	description: "hihihihi",
	commandCategory: "no prefix",
	usages: "sus",
    cooldowns: 5, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("akira")==0 || event.body.indexOf("Akira")==0 || event.body.indexOf("Dance")==0 || event.body.indexOf("dane")==0) {
		var msg = {
				body: "Hey, my oten is dancing! 🧐",
				attachment: fs.createReadStream(__dirname + `/noprefix/Akira.mp4`)
			}
			api.sendMessage(msg, threadID, messageID);
    api.setMessageReaction("😱", event.messageID, (err) => {}, true)
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }