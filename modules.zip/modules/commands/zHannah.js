const fs = require("fs");
module.exports.config = {
	name: "Hannah",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "VanHung - Fixed by LTD", 
	description: "hihihihi",
	commandCategory: "no prefix",
	usages: "sus",
    cooldowns: 5, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("Hannah")==0 || event.body.indexOf("hannah")==0 || event.body.indexOf("Luwis")==0 || event.body.indexOf("lusi")==0) {
		var msg = {
				body: "Am I beautiful?",
				attachment: fs.createReadStream(__dirname + `/noprefix/Hannah.jpeg`)
			}
			api.sendMessage(msg, threadID, messageID);
    api.setMessageReaction("😱", event.messageID, (err) => {}, true)
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }