const fs = require("fs");
module.exports.config = {
	name: "Cyrine",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "VanHung - Fixed by LTD", 
	description: "hihihihi",
	commandCategory: "no prefix",
	usages: "sus",
    cooldowns: 5, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("Mirror")==0 || event.body.indexOf("mirror")==0 || event.body.indexOf("Cyrine")==0 || event.body.indexOf("cyrine")==0) {
		var msg = {
				body: "Hello darling, do you like my outfit?",
				attachment: fs.createReadStream(__dirname + `/noprefix/Thirst.jpeg`)
			}
			api.sendMessage(msg, threadID, messageID);
    api.setMessageReaction("😱", event.messageID, (err) => {}, true)
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }