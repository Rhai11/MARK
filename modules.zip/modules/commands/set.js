const fs = require("fs");
module.exports.config = {
	name: "botrule",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "Siegfried Sama", 
	description: "no prefix",
	commandCategory: "No command marks needed",
	usages: "...",
    cooldowns: 1, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("about")==0 || (event.body.indexOf("About")==0 || (event.body.indexOf("rule")==0 || (event.body.indexOf("Rule")==0)))) {
    const moment = require("moment-timezone");
    var gio = moment.tz("Asia/Manila").format("HH:mm:ss || D/MM/YYYY");
		var msg = {
				body: "Hello, user! Do not spam the bot; otherwise, I will automatically ban you. If you send 20 messages as spam, your ID will be banned from this bot. Please avoid spamming.\n\nIf you encounter a sudden ban, contact the admin for assistance!\n\n🌐 Usage: !callrhai [Your issue]"
			}
			api.sendMessage(msg, threadID, messageID);
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }