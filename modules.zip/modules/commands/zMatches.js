const fs = require("fs");
module.exports.config = {
	name: "Matches",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "VanHung - Fixed by LTD", 
	description: "hihihihi",
	commandCategory: "no prefix",
	usages: "sus",
    cooldowns: 5, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("Match")==0 || event.body.indexOf("match")==0 || event.body.indexOf("Matches")==0 || event.body.indexOf("matches")==0) {
		var msg = {
				body: "Hello, this is my main hero and my hero matches!",
				attachment: fs.createReadStream(__dirname + `/noprefix/Matches.jpeg`)
			}
			api.sendMessage(msg, threadID, messageID);
    api.setMessageReaction("😱", event.messageID, (err) => {}, true)
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }