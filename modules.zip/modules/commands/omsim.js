module.exports.config = {
  name: "goiadmin",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "John Arida",
  description: "Bot will rep ng tag admin or rep ng tagbot ",
  commandCategory: "group",
  usages: "",
  cooldowns: 1
};
module.exports.handleEvent = function({ api, event }) {
  if (event.senderID !== "100082158565013") {
    var aid = ["100082158565013"];
    for (const id of aid) {
    if ( Object.keys(event.mentions) == id) {
      var msg = ["Don’t tag my admin. I will punch you!", "My admin is so handsome.", "Sorry, admin is offline.","Do you like my admin thats why your tagging him? "," Another tag in my admin, I will punch kill you."];
      api.setMessageReaction(""😡, event.messageID, (err) => {}, true);
      return api.sendMessage({body: msg[Math.floor(Math.random()*msg.length)]}, event.threadID, event.messageID);
    }
    }}
};
module.exports.run = async function({}) {
}