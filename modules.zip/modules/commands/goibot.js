const fs = global.nodemodule["fs-extra"];
module.exports.config = {
  name: "goibot",
  version: "1.0.1",
  hasPermssion: 0,
  credits: "manhIT",
  description: "goibot",
  commandCategory: "No prefix",
  usages: "noprefix",
  cooldowns: 5,
};
module.exports.handleEvent = async function({ api, event, args, Threads, Users }) {
  var { threadID, messageID, reason } = event;
  const moment = require("moment-timezone");
  const time = moment.tz("Asia/Ho_Chi_minh").format("HH:MM:ss L");
  var idgr = `${event.threadID}`;

  
var tl = ["greetings, how can I assist you today?","is there anything specific you’d like to discuss?","hello there, it’s nice to interact with you.","I’m here to provide information and answer your queries.","hey, how’s it going on your head Are you okay?","feel free to ask me anything you have in your mind.","hi, what brings you here today?","I’m ready to engage in conversation with you.","greetings, friend! what’s on your mind?","I’m here to chat and help with any questions you may have.","hello, how’s your day shaping up?","let me know if there’s something specific you’d like assistance with.","hey, hope everything is going well for you.","I’m at your disposal for any inquiries or discussions.","hi there, anything exciting happening on your day?","feel free to share, and I’ll respond accordingly.","hello, friend! what’s the latest in your world?","I’m here and ready for our conversation.","greetings! is there a particular topic you’d like to explore today?","I’m here to engage in a meaningful exchange with you.", "good day! How may I know if you are okay?","is there a specific matter you wish to talk about?","hi, it’s great to connect with you!","feel free to let me know how I can assist you.","salutations! What can i do for you right now?","your questions and thoughts are welcome.","hello! how are things on your end today?","I’m here to help and engage in conversation.","hey there! what’s on your agenda for today?","feel free to share, and we can discuss it together.","greetings! is there a particular topic that piques your interest?","I’m here to explore various subjects with you.","hello, friend! how’s your day unfolding?","let me know if there’s something specific you’d like to talk about.","hey, it’s nice to see you here!","I’m ready to assist or chat about anything you have in mind.","hi, how’s everything going for you right now?","feel free to share your thoughts or questions.","greetings and salutations! what’s the latest in your world?","I’m here to be a part of your conversation.","use ‘!callrhai’ to contact my admin."];
  
  var rand = tl[Math.floor(Math.random() * tl.length)]

  if (event.body.indexOf("bot") == 0 || (event.body.indexOf("Bot") == 0)) {
 let userH = event.senderID 
    /*api.getUserInfo(parseInt(userH), (err, data) => {
      if(err){ return console.log(err)}
     var obj = Object.keys(data);
    var firstname = data[obj].name.replace("@", ""); */
    
  const firstname = global.data.userName.get(userH) || await Users.getNameUser(userH);
	if (event.senderID == api.getCurrentUserID()) return;

    var msg = {
      body: firstname + ", " + rand, 
      mentions: [{
          tag: firstname,
          id: userH
        }]
    }
    return api.sendMessage(msg, threadID, messageID);
    //  })
  };
  let input2 = event.body.toLowerCase();
if(input2.includes("Mwa") || input2.includes("mwa") || input2.includes("lol") || input2.includes("Saan") || input2.includes("saan") || input2.includes("Ano") || input2.includes("ano") || input2.includes("Sige") || input2.includes("sige") || input2.includes("geh")){
					        	return api.setMessageReaction("👎", event.messageID, (err) => {}, true)
} 
    if(input2.includes("kawawa") || input2.includes("sad") || input2.includes("agoi") || input2.includes("ayoko") ||input2.includes("ayaw") || input2.includes("pain") || input2.includes("pighati")){
					        	return api.setMessageReaction("👍", event.messageID, (err) => {}, true)
    }


}

module.exports.run = function({ api, event, client, __GLOBAL }) { }