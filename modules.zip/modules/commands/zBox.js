const axios = require("axios");
const moment = require("moment-timezone");
let FONT_ENABLED = true;

module.exports.config = {
  name: "box",
  version: "1.2.0",
  hasPermission: 0,
  credits: "Hazeyy",
  description: "( 𝙱𝚕𝚊𝚌𝚔𝙱𝚘𝚡 𝙰𝙸 )",
  usePrefix: false,
  commandCategory: "Artificial intelligence",
  usages: "( 𝙼𝚘𝚍𝚎𝚕 - 𝙱𝚕𝚊𝚌𝚔𝙱𝚘𝚡 𝙰𝙸 )",
  cooldowns: 3,
};

let lastQuery = "";

module.exports.handleEvent = async function ({ api, event }) {
  const lowerCaseBody = event.body.toLowerCase();

  if (lowerCaseBody.startsWith("box on")) {
    FONT_ENABLED = true;
    api.sendMessage({
      body: `🤖 𝙱𝚕𝚊𝚌𝚔𝙱𝚘𝚡 𝙵𝚘𝚗𝚝\n\n» 🟢 𝙴𝚗𝚊𝚋𝚕𝚎𝚍 «`,
      attachment: null,
      mentions: [],
    }, event.threadID);
    return;
  }

  if (lowerCaseBody.startsWith("box off")) {
    FONT_ENABLED = false;
    api.sendMessage({
      body: `🤖 𝙱𝚕𝚊𝚌𝚔𝙱𝚘𝚡 𝙵𝚘𝚗𝚝\n\n» 🔴 𝙳𝚒𝚜𝚊𝚋𝚕𝚎𝚍 «`,
      attachment: null,
      mentions: [],
    }, event.threadID);
    return;
  }

  if (!lowerCaseBody.startsWith("box")) return;

  const args = event.body.split(/\s+/);
  args.shift();

  if (!args[0]) {
    api.sendMessage("🤖 𝙷𝚎𝚕𝚕𝚘 𝙸 𝚊𝚖 𝙱𝚕𝚊𝚌𝚔𝙱𝚘𝚡 𝙰𝙸 𝚝𝚛𝚊𝚒𝚗𝚎𝚍 𝚋𝚢 𝙶𝚘𝚘𝚐𝚕𝚎.\n\n𝙷𝚘𝚠 𝚖𝚊𝚢 𝚒 𝚊𝚜𝚜𝚒𝚜𝚝 𝚢𝚘𝚞 𝚝𝚘𝚍𝚊𝚢?", event.threadID, event.messageID);
    return;
  }

  const query = args.join(" ");

  if (query === lastQuery) {
    api.sendMessage("🕛 | 𝚄𝚙𝚍𝚊𝚝𝚎𝚍 𝙰𝚗𝚜𝚠𝚎𝚛 𝚝𝚘 𝚙𝚛𝚎𝚟𝚒𝚘𝚞𝚜 𝚚𝚞𝚎𝚜𝚝𝚒𝚘𝚗, 𝙿𝚕𝚎𝚊𝚜𝚎 𝚠𝚊𝚒𝚝...", event.threadID, event.messageID);
    return;
  } else {
    lastQuery = query;
  }

  api.sendMessage("🗨️ | 𝙱𝚕𝚊𝚌𝚔𝙱𝚘𝚡 𝙰𝙸 𝚒𝚜 𝚝𝚑𝚒𝚗𝚔𝚒𝚗𝚐...", event.threadID, event.messageID);

  try {
    const response = await axios.get(`https://code-merge-api-hazeyy01.replit.app/blackbox/ask?q=${encodeURIComponent(query)}`);

    if (response.status === 200 && response.data && response.data.message) {
      const answer = response.data.message;
      const formattedAnswer = formatFont(answer);
      const currentTimePH = formatFont(moment().tz('Asia/Manila').format('hh:mm:ss A'));

      api.sendMessage(`🎓 𝐁𝐥𝐚𝐜𝐤𝐁𝐨𝐱 ( 𝐀𝐈 )\n\n🖋️ 𝐀𝐬𝐤: '${query}'\n\n${formattedAnswer}\n\n» ⏰ 𝚃𝚒𝚖𝚎: .⋅ ۵ ${currentTimePH} ۵ ⋅. «`, event.threadID, event.messageID);
    } else {
      api.sendMessage("🚫 𝙴𝚛𝚛𝚘𝚛 𝚗𝚘 𝚛𝚎𝚕𝚎𝚟𝚊𝚗𝚝 𝚊𝚗𝚜𝚠𝚎𝚛 𝚏𝚘𝚞𝚗𝚍..", event.threadID, event.messageID);
    }
  } catch (error) {
    console.error(error);
    api.sendMessage("🚫 𝙰𝚗 𝚎𝚛𝚛𝚘𝚛 𝚘𝚌𝚌𝚞𝚛𝚎𝚍 𝚠𝚑𝚒𝚕𝚎 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐 𝚘𝚗 𝙱𝚕𝚊𝚌𝚔𝙱𝚘𝚡 𝙰𝙿𝙸...", event.threadID, event.messageID);
    return;
  }
};

function formatFont(text) {
  const FONT_MAPPING = {
    a: "a", b: "b", c: "c", d: "d", e: "e", f: "f", g: "g", h: "h", i: "i", j: "j", k: "k", l: "l", m: "m",
    n: "n", o: "o", p: "p", q: "q", r: "r", s: "s", t: "t", u: "u", v: "v", w: "w", x: "x", y: "y", z: "z",
    A: "A", B: "B", C: "C", D: "D", E: "E", F: "F", G: "G", H: "H", I: "I", J: "J", K: "J", L: "L", M: "M",
    N: "N", O: "O", P: "P", Q: "Q", R: "R", S: "S", T: "T", U: "U", V: "V", W: "W", X: "X", Y: "Y", Z: "Z"
  };

  let formattedOutput = "";
  for (const char of text) {
    if (FONT_ENABLED && char in FONT_MAPPING) {
      formattedOutput += FONT_MAPPING[char];
    } else {
      formattedOutput += char;
    }
  }

  return formattedOutput;
}

module.exports.run = async function ({ api, event }) {};