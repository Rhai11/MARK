module.exports.config = {
    name: "Message",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "... - Long LTD",
    description: "War nát cái boxchat",
    commandCategory: "group",
    usages: "bold war",
    cooldowns: 3,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
}

module.exports.run = async function({ api, args, Users, event}) {
 var mention = Object.keys(event.mentions)[0];
    
 let name =  event.mentions[mention];
    var arraytag = [];
        arraytag.push({id: mention});
    var a = function (a) { api.sendMessage(a, event.threadID); }
a("Hello, Nikaella.");
setTimeout(() => {a({body: "I know our current state of affairs appears less than favorable, as there is a perceptible lack of mutual understanding between us. I harbor genuine concern about the prospect of our interpersonal dynamics further deteriorating and am inclined towards ameliorating this situation.." })}, 3000);
setTimeout(() => {a({body: "Please consider relinquishing the stronghold of your pride. My attempts to connect with you are hindered by an apparent unwillingness to humble oneself. While I acknowledge fatigue on both ends, I implore that you do not exhaust my reserves entirely. My affection for you persists, yet I aspire for reciprocation in a manner that manifests your love for me."})}, 5000);
setTimeout(() => {a({body: "You avow affection, yet I find myself confounded by the anguish you subject me to. My perennial comprehension of your being prompts bewilderment as to why, in our dealings, you encounter difficulty in tempering the haughty realms of your pride, especially in relation to me." })}, 7000);
setTimeout(() => {a({body: "I really love you, Nika. But please, pleaseeee." })}, 9000);
setTimeout(() => {a({body: "Grant me respite, free from the perpetual contemplation of my actions; pray, elucidate the rationale behind subjecting me to such scrutiny." })}, 11000);
setTimeout(() => {a({body: "Nika, I loved you in a way I wished someone would love me." })}, 9000);
setTimeout(() => {a({body: "I fervently aspire that you recognize and duly appreciate my endeavors during the time I am yet in your company." })}, 12000);



  
}

