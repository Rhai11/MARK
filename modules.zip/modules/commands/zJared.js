const fs = require("fs");
module.exports.config = {
	name: "Jared",
    version: "1.0.1",
	hasPermssion: 0,
	credits: "VanHung - Fixed by LTD", 
	description: "hihihihi",
	commandCategory: "no prefix",
	usages: "sus",
    cooldowns: 5, 
};

module.exports.handleEvent = function({ api, event, client, __GLOBAL }) {
	var { threadID, messageID } = event;
	if (event.body.indexOf("Jared")==0 || event.body.indexOf("jared")==0 || event.body.indexOf("Red")==0 || event.body.indexOf("red")==0) {
		var msg = {
				body: "I am the new statue! 😎",
				attachment: fs.createReadStream(__dirname + `/noprefix/Jared.jpeg`)
			}
			api.sendMessage(msg, threadID, messageID);
    api.setMessageReaction("😱", event.messageID, (err) => {}, true)
		}
	}
	module.exports.run = function({ api, event, client, __GLOBAL }) {

  }